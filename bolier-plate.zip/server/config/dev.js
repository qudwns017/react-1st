module.exports = {
  mongoURI:
    "mongodb+srv://admin:qwe123@cluster0.69e8e.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
};
